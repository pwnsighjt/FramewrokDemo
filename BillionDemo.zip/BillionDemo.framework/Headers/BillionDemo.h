//
//  BillionDemo.h
//  BillionDemo
//
//  Created by Pawan Jat on 06/04/17.
//  Copyright © 2017 47billion. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BillionDemo.
FOUNDATION_EXPORT double BillionDemoVersionNumber;

//! Project version string for BillionDemo.
FOUNDATION_EXPORT const unsigned char BillionDemoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BillionDemo/PublicHeader.h>


#import <BillionDemo/InsertManager.h>
